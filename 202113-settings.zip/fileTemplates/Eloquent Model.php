<?php

#if (${NAMESPACE})

namespace ${NAMESPACE};

#end

class ${NAME} extends Eloquent {
	protected \$fillable = [];
}